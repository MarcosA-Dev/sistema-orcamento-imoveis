from funcoes.sistema import executar_sistema

if __name__ == "__main__":
    executar_sistema()
